
export interface StandardPillar {
  label: string;
  title: string;
  description: string;
}

export interface DiamondSpec {
  label: string;
  value: string;
  sub: string;
}
