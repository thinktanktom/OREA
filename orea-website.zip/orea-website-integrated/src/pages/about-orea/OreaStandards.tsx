import React from 'react';

export const OreaStandards: React.FC = () => {
  return (
    <section className="space-y-48">
      <div className="max-w-4xl mx-auto text-center space-y-4">
        <h2 className="text-5xl md:text-7xl font-serif text-[#4A3F35] leading-tight">
          The ORÉA Standards
        </h2>
        <p className="text-lg md:text-xl font-serif text-[#7D6B5C]">
          ORÉA works within a considered framework
        </p>
      </div>

      <div className="max-w-5xl mx-auto space-y-40">
        {/* Pillar 1: Metals */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-20 items-center">
          <div className="space-y-8">
            <div className="w-12 h-12 border border-[#D4C4A8] rounded-full flex items-center justify-center">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#4A3F35" strokeWidth="1">
                <path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z" />
                <path d="M12 6a6 6 0 100 12 6 6 0 000-12z" />
              </svg>
            </div>
            <h3 className="text-3xl font-serif text-[#4A3F35] tracking-tight">Solid Precious Metals</h3>
            <div className="space-y-6 text-[#7D6B5C] leading-relaxed font-light text-lg">
              <p>
                We work only in solid 14k or 18k gold and platinum — never plated, filled, or vermeil.
              </p>
              <p className="text-[#4A3F35] font-normal">
                Precious metals are inherently durable, repairable, and made to last.
              </p>
            </div>
          </div>
          
          <div className="bg-[#E8DFD3] aspect-[4/3] flex items-center justify-center border border-[#D4C4A8]/30">
             <span className="text-[9px] uppercase tracking-[0.4em] text-[#7D6B5C] font-semibold">Solid Metals Image Slot</span>
          </div>
        </div>

        {/* Pillar 2: Diamonds */}
        <div className="space-y-16">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-20 items-center">
            <div className="order-2 md:order-1 bg-[#E8DFD3] aspect-[4/3] flex items-center justify-center border border-[#D4C4A8]/30">
              <span className="text-[9px] uppercase tracking-[0.4em] text-[#7D6B5C] font-semibold">Lab Diamond Image Slot</span>
            </div>
            
            <div className="order-1 md:order-2 space-y-8">
              <div className="w-12 h-12 border border-[#D4C4A8] rounded-full flex items-center justify-center">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#4A3F35" strokeWidth="1">
                  <path d="M6 3h12l4 6-10 12L2 9l4-6z" />
                </svg>
              </div>
              <h3 className="text-3xl font-serif text-[#4A3F35] tracking-tight">Certified Premium Diamonds</h3>
              <p className="text-[#7D6B5C] leading-relaxed font-light text-lg">
                ORÉA works exclusively with certified lab-grown diamonds, selected for exceptional brilliance and traceable quality. 
              </p>
              <p className="text-[#7D6B5C] leading-relaxed font-light text-lg">
                For centre stones over 1 carat, we offer only diamonds that meet our highest minimum standards, independently graded by IGI.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 bg-[#E8DFD3] p-12 border border-[#D4C4A8]/20">
            {[
              { label: "Cut", value: "Excellent / Ideal", sub: "maximized brilliance" },
              { label: "Clarity", value: "VS and above", sub: "Eye-clean" },
              { label: "Colour", value: "D — F", sub: "Colourless" }
            ].map((spec, i) => (
              <div key={i} className="text-center space-y-3">
                <span className="text-[10px] uppercase tracking-[0.4em] text-[#7D6B5C] font-bold">{spec.label}</span>
                <div className="text-2xl font-serif text-[#4A3F35]">{spec.value}</div>
                <div className="text-[9px] uppercase tracking-widest text-[#7D6B5C] font-medium">{spec.sub}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Pillar 3 & 4: Experience & Warranty */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-px bg-[#D4C4A8]/30 border border-[#D4C4A8]/20">
          <div className="bg-[#F9F6F1] p-16 space-y-10 group transition-all duration-700 hover:bg-[#E8DFD3]/20">
            <div className="w-12 h-12 border border-[#E8DFD3] rounded-full flex items-center justify-center group-hover:border-[#4A3F35] transition-colors">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#4A3F35" strokeWidth="1.2">
                <path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z" />
              </svg>
            </div>
            <div className="space-y-6">
              <h3 className="text-2xl font-serif text-[#4A3F35] tracking-tight">Guided, Never Rushed</h3>
              <p className="text-[#7D6B5C] font-light text-base leading-relaxed">
                We offer a calm, consultation-led experience — never pressure, never urgency. Whether you are choosing a signature piece or designing bespoke, you will be guided with clarity and care.
              </p>
            </div>
          </div>

          <div className="bg-[#F9F6F1] p-16 space-y-10 group transition-all duration-700 hover:bg-[#E8DFD3]/20">
            <div className="w-12 h-12 border border-[#E8DFD3] rounded-full flex items-center justify-center group-hover:border-[#4A3F35] transition-colors">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#4A3F35" strokeWidth="1.2">
                <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
              </svg>
            </div>
            <div className="space-y-6">
              <h3 className="text-2xl font-serif text-[#4A3F35] tracking-tight">Designed to Last</h3>
              <p className="text-[#7D6B5C] font-light text-base leading-relaxed">
                ORÉA jewellery is crafted for everyday wear and long-term keeping. Engagement and wedding rings include a Lifetime Manufacturing Warranty, supporting longevity well beyond the moment of purchase.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};