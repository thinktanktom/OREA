export interface NavLink {
  label: string;
  href: string;
}

export interface ConciergeFeature {
  label: string;
}