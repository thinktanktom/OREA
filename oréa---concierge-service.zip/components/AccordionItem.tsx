// Deprecated - This layout no longer uses accordions to maintain a product-focused editorial feel.
export {};