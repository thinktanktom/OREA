import React, { useState } from 'react';
import AccordionItem from './components/AccordionItem';
import { CARE_GUIDE_FAQ, CARE_GUIDE_INTRO_1, CARE_GUIDE_INTRO_2 } from './constants.tsx';

const App: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <div className="min-h-screen flex flex-col bg-[#F9F6F1]">
      <main className="flex-grow">
        {/* Page Hero Section */}
        <section className="pt-24 pb-16 px-6 lg:px-12 text-center">
          <div className="max-w-5xl mx-auto">
            <h1 className="serif-heading text-4xl md:text-6xl font-light tracking-[0.05em] mb-8 animate-fade-in text-[#4A3F35]">
              Product Care Guide
            </h1>
            <div className="w-16 h-[1px] bg-[#C5B8A0] mx-auto mb-10"></div>
            
            {/* Introductory Content - Width matched to FAQ (max-w-5xl) and Left Aligned. Size slightly reduced. */}
            <div className="max-w-5xl mx-auto text-left text-[#7D6B5C] font-light text-[14px] md:text-[15.5px] mb-12 animate-fade-in tracking-wide">
              <p className="leading-relaxed mb-4">
                {CARE_GUIDE_INTRO_1}
              </p>
              <p className="leading-relaxed">
                {CARE_GUIDE_INTRO_2}
              </p>
            </div>
          </div>
        </section>

        {/* Content Accordion Section */}
        <section className="px-6 lg:px-12 pb-32">
          <div className="max-w-5xl mx-auto">
            <div className="border-t border-[#E8DFD3]">
              {CARE_GUIDE_FAQ.map((item, index) => (
                <AccordionItem
                  key={index}
                  question={item.question}
                  answer={item.answer}
                  isOpen={openIndex === index}
                  onClick={() => setOpenIndex(openIndex === index ? null : index)}
                />
              ))}
            </div>
          </div>
        </section>
      </main>
    </div>
  );
};

export default App;