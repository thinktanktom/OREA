import React from 'react';
import { FAQItem } from './types';

export const CARE_GUIDE_INTRO_1 = "ORÉA jewellery is designed to be worn, loved, and lived in. Each piece is crafted using lab-grown diamonds and solid gold, chosen for their beauty and longevity.";
export const CARE_GUIDE_INTRO_2 = "With thoughtful care, your jewellery will maintain its brilliance and structure for years to come. Gentle attention helps keep each piece luminous.";

export const CARE_GUIDE_FAQ: FAQItem[] = [
  {
    question: "Diamond Care",
    answer: "Lab-grown diamonds share the same physical, chemical, and optical properties as mined diamonds. They are exceptionally durable, but they are not indestructible.\n\nDiamonds naturally attract oils and residue from skin, cosmetics, and everyday wear, which can soften their sparkle over time. Regular gentle cleaning will help restore their brilliance. While diamonds are the hardest known gemstone, they can still chip or loosen if subjected to impact or pressure, particularly in exposed or delicate settings.\n\nWe recommend periodically checking diamond settings to ensure stones remain secure, especially for rings worn daily. If you notice movement or feel unsure, discontinue wear and contact us for professional assessment."
  },
  {
    question: "Gold Care",
    answer: "ORÉA pieces are crafted in solid gold, designed to age beautifully with wear. Over time, gold will naturally develop fine surface marks and a soft patina. This is expected and reflects a piece that is truly lived in.\n\nTo preserve the finish of your jewellery, avoid prolonged exposure to chemicals such as chlorine, bleach, and household cleaning products. These substances can dull gold and weaken settings over time. Removing jewellery before bathing, swimming, exercising, or cleaning helps protect both the metal and the structural integrity of the piece.\n\nProfessional polishing can restore shine if desired, though many clients choose to embrace the natural character that develops with wear."
  },
  {
    question: "Daily Care",
    answer: "Fine jewellery benefits from mindful habits. We recommend putting jewellery on last, after perfumes, lotions, sunscreen, and cosmetics have been applied. Remove jewellery before physical activity, sleeping, or any task involving impact or pressure.\n\nWhile designed for everyday elegance, fine jewellery should be treated as a delicate object rather than an accessory without limits."
  },
  {
    question: "Storage",
    answer: "When not worn, store your jewellery individually in a soft pouch or lined jewellery box. Keeping pieces separate helps prevent scratches and unnecessary wear. Store jewellery in a dry environment, away from direct sunlight and humidity."
  },
  {
    question: "Ring Resizing",
    answer: "Ring resizing depends on the design and setting of the piece. Some styles can be resized within a limited range, while others, such as eternity or intricate designs, may not be suitable for resizing.\n\nResizing is a structural alteration and may slightly affect proportions or finish. It is not considered a manufacturing fault. For the best result, we recommend confirming your ring size before placing an order and contacting us if you are unsure."
  },
  {
    question: "Cleaning Your Jewellery",
    answer: "Regular gentle cleaning will keep your jewellery looking its best.\n\nClean your piece by soaking it briefly in warm water with a small amount of mild dish soap. Use a soft toothbrush to gently clean around diamonds and settings, then rinse thoroughly and pat dry with a soft, lint-free cloth.\n\nAvoid abrasive materials, harsh chemicals, ultrasonic cleaners, or steam cleaning at home, as these may damage settings or finishes if not professionally handled.\n\nIf you are unsure how to clean a specific piece, please contact us before attempting any cleaning."
  },
  {
    question: "Professional Servicing",
    answer: "We recommend professional inspection and servicing every 12–24 months, particularly for rings worn frequently. This allows stone settings, prongs, and clasps to be checked for security and wear.\n\nProfessional servicing can help prevent minor issues from developing into larger concerns and ensures your jewellery remains safe and wearable over time."
  },
  {
    question: "Do you offer professional care for ORÉA jewellery?",
    answer: (
      <>
        Yes. The ORÉA Concierge Service provides three-year care and repair coverage for your piece.
        <br /><br />
        <a 
          href="/concierge-service" 
          className="underline underline-offset-4 hover:text-[#4A3F35] transition-colors"
        >
          Learn more here
        </a>
      </>
    )
  }
];