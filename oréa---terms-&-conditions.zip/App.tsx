import React from 'react';
import TermsPage from './components/TermsPage';

/**
 * SHOPIFY CLEANUP CHECKLIST
 * =========================
 * 
 * A) FILES KEPT:
 * - index.html (Main template & Tailwind theme config)
 * - index.tsx (Mounting logic)
 * - App.tsx (Active render path)
 * - components/TermsPage.tsx (Active page component)
 * 
 * B) FILES CLEARED (Safe to delete manually):
 * - components/Navbar.tsx
 * - components/Footer.tsx
 * 
 * C) DEPENDENCIES:
 * - No changes to package.json. Standard React/Tailwind dependencies apply.
 * 
 * CSS FLAG:
 * - 'selection:bg-orea-accent' was referenced but not defined in tailwind.config. 
 *   Updated to 'selection:bg-orea-linen' to match the active brand palette.
 */

const App: React.FC = () => {
  return (
    <div className="min-h-screen selection:bg-orea-linen selection:text-orea-text py-20">
      <main>
        <TermsPage />
      </main>
    </div>
  );
};

export default App;