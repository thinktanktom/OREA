
import React, { useState } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Collections from './components/Collections';
import BrandValues from './components/BrandValues';
import FeaturedProducts from './components/FeaturedProducts';
import Footer from './components/Footer';
import ShopifyPortingKit from './components/ShopifyPortingKit';

const App: React.FC = () => {
  const [devMode, setDevMode] = useState(false);

  return (
    <div className={`min-h-screen font-sans bg-orea-cream selection:bg-orea-champagne selection:text-orea-dark ${devMode ? 'pr-[400px]' : ''} transition-all duration-500`}>
      <Navbar />
      
      <main>
        <Hero 
          settings={{
            heading: "Diamonds. Grown. Not Mined.",
            subheading: "Exceptional pieces, made to keep.",
            button_label: "Explore the Collections",
            image: "https://placehold.co/1920x1080/F9F6F1/D4C4A8?text=HERO+IMAGE"
          }}
        />

        <Collections />

        <FeaturedProducts />

        <BrandValues />
      </main>

      <Footer />

      {/* Porting Tool Toggle */}
      <button 
        onClick={() => setDevMode(!devMode)}
        className="fixed bottom-6 right-6 z-[100] bg-orea-dark text-orea-cream px-6 py-3 rounded-full text-[10px] tracking-widest uppercase font-bold shadow-2xl hover:bg-orea-gold transition-colors flex items-center gap-3"
      >
        <div className={`w-2 h-2 rounded-full ${devMode ? 'bg-green-400' : 'bg-orea-champagne animate-pulse'}`}></div>
        {devMode ? 'Close Shopify Kit' : 'Shopify Porting Kit'}
      </button>

      {/* Shopify Liquid Sidebar */}
      {devMode && <ShopifyPortingKit />}
    </div>
  );
};

export default App;
